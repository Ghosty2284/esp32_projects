#include <DMD32.h>                  // DMD library for P10 LED matrix
#include "SystemFont4x4.h"        // 5×7 system font

#define DISPLAYS_ACROSS 2           // two 32 px‑wide panels = 64 px wide
#define DISPLAYS_DOWN   1           // one 16 px‑tall panel
DMD dmd(DISPLAYS_ACROSS, DISPLAYS_DOWN);

hw_timer_t* timer = nullptr;         // hardware timer for display refresh

// ISR to refresh display
void IRAM_ATTR triggerScan() {
  dmd.scanDisplayBySPI();
}

void setup() {
  Serial.begin(115200);

  // init timer for DMD refresh
  uint8_t cpuMHz = ESP.getCpuFreqMHz();
  timer = timerBegin(0, cpuMHz, true);
  timerAttachInterrupt(timer, &triggerScan, true);
  timerAlarmWrite(timer, 300, true);
  timerAlarmEnable(timer);

  // select font
  dmd.selectFont(SystemFont4x4);
}

void loop() {
  // Sample values
  const char* labels[] = {"h1", "h2", "h3", "h4"};
  const char* values[] = {"123", "345", "456", "678"};

  // STATIC DISPLAY WITH SEPARATORS
  dmd.clearScreen(false);
  int totalW = DISPLAYS_ACROSS * 32;  // 64
  int colW   = totalW / 4;            // 16 per column

  // draw vertical separators at column edges
  for (int i = 1; i < 4; i++) {
    int x = i * colW;
    dmd.drawLine(x, 0, x, 15, GRAPHICS_NORMAL);
  }

  // draw labels and values centered in each column
  for (int i = 0; i < 4; i++) {
    int baseX = i * colW;
    // label on top (y=0)
    int wL = strlen(labels[i]) * 6;
    int xL = baseX + (colW - wL) / 2;
    dmd.drawString(xL, 0, labels[i], strlen(labels[i]), GRAPHICS_NORMAL);
    // value on bottom (y=8)
    int wV = strlen(values[i]) * 6;
    int xV = baseX + (colW - wV) / 2;
    dmd.drawString(xV, 8, values[i], strlen(values[i]), GRAPHICS_NORMAL);
  }

  // hold static for 8 seconds
  delay(8000);

  // CONTINUOUS SCROLL LEFT→RIGHT
  const char* topLine    = "h1|h2|h3|h4";
  const char* bottomLine = "123|345|456|678";
  int textW = strlen(topLine) * 6;
  int startX = -textW;
  unsigned long lastStep;
  const unsigned long interval = 30;

  while (true) {
    dmd.clearScreen(false);
    dmd.drawMarquee(topLine,    strlen(topLine),    startX, 0);
    dmd.drawMarquee(bottomLine, strlen(bottomLine), startX, 8);
    bool done1=false, done2=false;
    lastStep = millis();
    while (!(done1 && done2)) {
      if (millis() - lastStep >= interval) {
        if (!done1) done1 = dmd.stepMarquee(1, 0);
        if (!done2) done2 = dmd.stepMarquee(1, 8);
        lastStep = millis();
      }
    }
    startX = -textW;
  }
}
sample output ?

