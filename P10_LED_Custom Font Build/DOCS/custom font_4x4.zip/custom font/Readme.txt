Readme


Place the font file in fonts folder of DMD32 library


Location :  Arduino => Libraries => DMD32 => fonts 